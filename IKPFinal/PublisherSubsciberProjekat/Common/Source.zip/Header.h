#pragma once

#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>


int Recv(SOCKET s, char* buff,int size);

int Send(SOCKET s, char* buff, int lenght);

SOCKET Connect(char *adress,int port);

bool InitializeWindowsSockets();

int Select(SOCKET s,int pom);


